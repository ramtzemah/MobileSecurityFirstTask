package com.example.securitiesles1;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;


public class MainActivity extends AppCompatActivity {
    private MaterialButton first;
    private MaterialTextView text;
    private SensorManager mSensorManager;
    private MovementSensors sensors;
    private SensorEventListener sensorEventListener = initSensorListener();
    private BatteryManager myBatteryManager;
    private boolean isCharge;
    private boolean isStable;
    private boolean isWIFI;
    private final double deviation = 1.5;
    private ConnectivityManager connManager;
    private NetworkInfo mWifi;
    ConnectivityManager cm;
    NetworkInfo activeNetwork;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();

        first.setOnClickListener(v -> {
            isWIFIConnect();
            isUSBCharging();
            if(isCharge && isStable && isWIFI) {
                Intent intent = new Intent(MainActivity.this, secondActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }else {
                Toast.makeText(this, "You didn't do enough things to move on to the next level",Toast.LENGTH_LONG).show();
            }
        });


    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public void isUSBCharging(){
        isCharge = myBatteryManager.isCharging();
    }
    public void isWIFIConnect(){
        activeNetwork = cm.getActiveNetworkInfo();
        if(activeNetwork != null) {
            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                isWIFI = true;
            } else {
                isWIFI = false;
            }
        }
    }

    private SensorEventListener initSensorListener() {
        return  new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                float y = sensorEvent.values[1];
                if(y >= -(deviation) && y <= deviation){
                    isStable = true;
                }else{
                    isStable = false;
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };
    }

    private void findViews() {
        first = findViewById(R.id.first);
        text = findViewById(R.id.text);
        //// Movement ////
        // Get sensor manager
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // Get the default sensor of specified type
        sensors = new MovementSensors()
                .setActivity(this)
                .setSensorManager(mSensorManager)
                .setAccSensor(mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));

        //// Charge ////
        myBatteryManager = (BatteryManager) this.getSystemService(Context.BATTERY_SERVICE);

        //// WIFI ////
         cm =
                (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensors.registerLisener(sensorEventListener,SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensors != null) {
            sensors.unregisterListener();
        }
    }
}
