package com.example.securitiesles1;

import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

public class CmManager {
    public static boolean isFlashlightOn = false;
    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void registerFlashlightState (Context context){
        CameraManager cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        cameraManager.registerTorchCallback(torchCallback, null);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void unregisterFlashlightState(Context context) {
        CameraManager cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        cameraManager.unregisterTorchCallback(torchCallback);
    }

    private static CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeChanged(@NonNull String cameraId, boolean enabled) {
            super.onTorchModeChanged(cameraId, enabled);
            isFlashlightOn = enabled;
        }
    };
}